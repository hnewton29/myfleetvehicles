import {useState} from "react"
import vehiclesData from "./data/vehicles.json"

function App() {
  const [divisionFilter, setDivisionFilter] = useState("All");

  const division = ["All", ...new Set(vehiclesData.map(v => v.division))];
  
  const filteredVehicles = divisionFilter === "All"
    ? vehiclesData
    : vehiclesData.filter(v => v.division === divisionFilter);

  const totalKms = filteredVehicles.reduce((sum, v) => sum + v.kms, 0);
  
  const kmsByDivision =  vehiclesData.reduce((acc, v) => {
      acc[v.division] = (acc[v.division] || 0) + v.kms
      return acc
    }, {});

  return (
        <div className="min-h-screen bg-gray-100 p-10">

          <h1 className="text-3xl font-bold mb-6">Fleet Dashboard</h1>

          {/* Filter */}
          <div className="mb-6">
            <label className="mr-3 font-semibold">Division</label>
            <select
              className="border rounded p-2"
              value={divisionFilter}
              onChange={(e) => setDivisionFilter(e.target.value)}
            >
           {division.map((d) => (
            <option key={d}>{d}</option>
           ))} 
          </select>
          </div>

          {/* Vehicles Table */}
          <div className="bg-white rounded-lg shadow overflow-auto mb-6">
            <table className="w-full table-auto border-collapse">
            <thead>
              <tr>
                <th className="px-4 py-2 border-gray-300">Rego</th>
                <th className="px-4 py-2 border-gray-300">Kms</th>
                <th className="px-4 py-2 border-gray-300">Division</th>
              </tr>
            </thead>
            <tbody>
              {filteredVehicles.map((v, i) => (
                <tr key={i} className="border-t hover:bg-gray-50">
                  <td className="px-4 py-2 border-gray-300 text-center">{v.rego}</td>
                  <td className="px-4 py-2 border-gray-300 text-center">{v.kms}</td>
                  <td className="px-4 py-2 border-gray-300 text-center">{v.division}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          
          {/* Summary kms*/}
          <div className="bg-white p-6 rounded-lg shadow mb-6">
            <h2 className="text-lg font-semibold mb-2">
               {divisionFilter ==="All" 
                ? "Total Fleet Kms travelled"
                : `Total ${divisionFilter} Kms`} 
              </h2>
              <p className="text-3xl font-bold text-blue-600">{totalKms}
              </p>
          </div>
        </div>
  );
}

export default App;
